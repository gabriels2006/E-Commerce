package utils;

import models.Client;
import models.Product;
import models.Order;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DataStore {
    
    private static DataStore instance;
    
    private List<Client> clients;
    private List<Product> products;
    private List<Order> orders;
    private Client currentClient;
    
    private DataStore() {
        clients = new ArrayList<>();
        products = new ArrayList<>();
        orders = new ArrayList<>();
        initializeProducts();
    }
    
    public static DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }
    
    private void initializeProducts() {
        // Notebooks
        products.add(new Product("Notebook Dell XPS 13", "Ultrabook leve e potente, ideal para trabalho e estudos", 
            4500.0f, 15, "Notebooks", "Dell", "XPS 13", "Dell Inc.", LocalDate.of(2023, 5, 10)));
        
        products.add(new Product("Notebook Lenovo ThinkPad", "Notebook corporativo com alta durabilidade", 
            5200.0f, 10, "Notebooks", "Lenovo", "ThinkPad X1", "Lenovo", LocalDate.of(2023, 6, 15)));
        
        products.add(new Product("Notebook Asus ROG", "Notebook gamer de alta performance", 
            8900.0f, 8, "Notebooks", "Asus", "ROG Strix", "Asus", LocalDate.of(2023, 7, 20)));
        
        // Smartphones
        products.add(new Product("Samsung Galaxy S23", "Smartphone premium com câmera de 200MP", 
            3800.0f, 25, "Smartphones", "Samsung", "Galaxy S23", "Samsung Electronics", LocalDate.of(2023, 3, 1)));
        
        products.add(new Product("iPhone 15 Pro", "iPhone com chip A17 Pro e titânio", 
            7500.0f, 12, "Smartphones", "Apple", "iPhone 15 Pro", "Apple Inc.", LocalDate.of(2023, 9, 15)));
        
        products.add(new Product("Xiaomi Redmi Note 13", "Smartphone com excelente custo-benefício", 
            1500.0f, 30, "Smartphones", "Xiaomi", "Redmi Note 13", "Xiaomi", LocalDate.of(2023, 8, 10)));
        
        // Periféricos
        products.add(new Product("Mouse Logitech MX Master 3", "Mouse ergonômico sem fio", 
            450.0f, 40, "Periféricos", "Logitech", "MX Master 3", "Logitech", LocalDate.of(2023, 1, 15)));
        
        products.add(new Product("Teclado Mecânico Keychron K2", "Teclado mecânico wireless", 
            650.0f, 20, "Periféricos", "Keychron", "K2", "Keychron", LocalDate.of(2023, 2, 20)));
        
        products.add(new Product("Webcam Logitech C920", "Webcam Full HD 1080p", 
            380.0f, 35, "Periféricos", "Logitech", "C920", "Logitech", LocalDate.of(2023, 4, 5)));
        
        // Monitores
        products.add(new Product("Monitor LG UltraWide 29''", "Monitor ultrawide 29 polegadas", 
            1800.0f, 18, "Monitores", "LG", "29WP500", "LG Electronics", LocalDate.of(2023, 5, 25)));
        
        products.add(new Product("Monitor Samsung Odyssey G5", "Monitor gamer curvo 27'' 144Hz", 
            2200.0f, 12, "Monitores", "Samsung", "Odyssey G5", "Samsung Electronics", LocalDate.of(2023, 6, 30)));
        
        // Fones de Ouvido
        products.add(new Product("Fone Sony WH-1000XM5", "Fone com cancelamento de ruído premium", 
            1900.0f, 22, "Áudio", "Sony", "WH-1000XM5", "Sony Corporation", LocalDate.of(2023, 3, 12)));
        
        products.add(new Product("AirPods Pro 2", "Fones true wireless da Apple", 
            2100.0f, 28, "Áudio", "Apple", "AirPods Pro 2", "Apple Inc.", LocalDate.of(2023, 9, 20)));
        
        // Tablets
        products.add(new Product("iPad Air M2", "Tablet Apple com chip M2", 
            5500.0f, 10, "Tablets", "Apple", "iPad Air", "Apple Inc.", LocalDate.of(2023, 10, 5)));
        
        products.add(new Product("Samsung Galaxy Tab S9", "Tablet Android premium", 
            3200.0f, 15, "Tablets", "Samsung", "Galaxy Tab S9", "Samsung Electronics", LocalDate.of(2023, 8, 15)));
    }
    
    // Métodos para Clientes
    public void addClient(Client client) {
        clients.add(client);
    }
    
    public Client authenticateClient(String email, String password) {
        for (Client client : clients) {
            if (client.getEmail().equals(email) && client.getPassword().equals(password)) {
                return client;
            }
        }
        return null;
    }
    
    public boolean emailExists(String email) {
        for (Client client : clients) {
            if (client.getEmail().equals(email)) {
                return true;
            }
        }
        return false;
    }
    
    // Métodos para Produtos
    public List<Product> getProducts() {
        return products;
    }
    
    public List<Product> getProductsByCategory(String category) {
        List<Product> filtered = new ArrayList<>();
        for (Product product : products) {
            if (product.getCategory().equals(category)) {
                filtered.add(product);
            }
        }
        return filtered;
    }
    
    public List<String> getCategories() {
        List<String> categories = new ArrayList<>();
        for (Product product : products) {
            if (!categories.contains(product.getCategory())) {
                categories.add(product.getCategory());
            }
        }
        return categories;
    }
    
    public void addProduct(Product product) {
        products.add(product);
    }
    
    // Métodos para Pedidos
    public void addOrder(Order order) {
        orders.add(order);
    }
    
    public List<Order> getOrdersByClient(Client client) {
        List<Order> clientOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getClient().equals(client)) {
                clientOrders.add(order);
            }
        }
        return clientOrders;
    }
    
    // Cliente atual (sessão)
    public Client getCurrentClient() {
        return currentClient;
    }
    
    public void setCurrentClient(Client client) {
        this.currentClient = client;
    }
    
    public void logout() {
        this.currentClient = null;
    }
}
